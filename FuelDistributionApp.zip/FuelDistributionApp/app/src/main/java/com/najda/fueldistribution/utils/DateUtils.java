package com.najda.fueldistribution.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class DateUtils {

    public static final String DATE_FORMAT = "yyyy-MM-dd";
    public static final String MONTH_FORMAT = "yyyy-MM";

    public static String today() {
        return new SimpleDateFormat(DATE_FORMAT, Locale.US).format(new java.util.Date());
    }

    public static String currentMonthPrefix() {
        return new SimpleDateFormat(MONTH_FORMAT, Locale.US).format(new java.util.Date());
    }

    /** Converts a yyyy-MM-dd string to a friendlier display, or returns it unchanged if it doesn't parse. */
    public static String displayDate(String isoDate) {
        return isoDate == null ? "" : isoDate;
    }

    public static String monthLabel(String yearMonthPrefix) {
        try {
            String[] parts = yearMonthPrefix.split("-");
            int year = Integer.parseInt(parts[0]);
            int month = Integer.parseInt(parts[1]);
            String[] names = {"يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
                    "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"};
            return names[month - 1] + " " + year;
        } catch (Exception e) {
            return yearMonthPrefix;
        }
    }
}
