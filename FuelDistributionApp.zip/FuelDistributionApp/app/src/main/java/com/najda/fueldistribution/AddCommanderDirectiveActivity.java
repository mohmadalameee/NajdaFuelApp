package com.najda.fueldistribution;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.najda.fueldistribution.models.CommanderDirective;
import com.najda.fueldistribution.utils.DateUtils;

import java.util.Calendar;
import java.util.Locale;

public class AddCommanderDirectiveActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private EditText etDirective, etDate, etBeneficiary, etQuantity, etReason, etNotes;
    private String selectedDate;
    private long directiveId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_commander_directive);

        db = DatabaseHelper.getInstance(this);

        etDirective = findViewById(R.id.etDirective);
        etDate = findViewById(R.id.etDate);
        etBeneficiary = findViewById(R.id.etBeneficiary);
        etQuantity = findViewById(R.id.etQuantity);
        etReason = findViewById(R.id.etReason);
        etNotes = findViewById(R.id.etNotes);
        Button btnSave = findViewById(R.id.btnSave);
        Button btnDelete = findViewById(R.id.btnDelete);

        selectedDate = DateUtils.today();
        etDate.setText(selectedDate);
        etDate.setOnClickListener(v -> showDatePicker());

        directiveId = getIntent().getLongExtra(CommanderDirectivesActivity.EXTRA_DIRECTIVE_ID, -1);
        if (directiveId > 0) {
            btnDelete.setVisibility(android.view.View.VISIBLE);
            for (CommanderDirective d : db.getAllCommanderDirectives()) {
                if (d.getId() == directiveId) {
                    etDirective.setText(d.getDirectiveNumber());
                    etDate.setText(d.getDate());
                    selectedDate = d.getDate();
                    etBeneficiary.setText(d.getBeneficiaryName());
                    etQuantity.setText(formatNumber(d.getQuantity()));
                    etReason.setText(d.getReason());
                    etNotes.setText(d.getNotes());
                    break;
                }
            }
        }

        btnSave.setOnClickListener(v -> save());
        btnDelete.setOnClickListener(v -> confirmDelete());
    }

    private void showDatePicker() {
        Calendar cal = Calendar.getInstance();
        try {
            String[] parts = selectedDate.split("-");
            cal.set(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]) - 1, Integer.parseInt(parts[2]));
        } catch (Exception ignored) {}

        new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            selectedDate = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, dayOfMonth);
            etDate.setText(selectedDate);
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void save() {
        String beneficiary = text(etBeneficiary);
        if (beneficiary.isEmpty()) {
            etBeneficiary.setError(getString(R.string.field_required));
            return;
        }
        double quantity;
        try {
            quantity = Double.parseDouble(text(etQuantity));
        } catch (NumberFormatException e) {
            etQuantity.setError(getString(R.string.field_required));
            return;
        }

        CommanderDirective d = new CommanderDirective();
        d.setId(directiveId);
        d.setDirectiveNumber(text(etDirective));
        d.setDate(selectedDate);
        d.setBeneficiaryName(beneficiary);
        d.setQuantity(quantity);
        d.setReason(text(etReason));
        d.setNotes(text(etNotes));

        if (directiveId > 0) {
            db.updateCommanderDirective(d);
        } else {
            db.insertCommanderDirective(d);
        }
        Toast.makeText(this, R.string.saved_success, Toast.LENGTH_SHORT).show();
        finish();
    }

    private void confirmDelete() {
        new AlertDialog.Builder(this)
                .setMessage(R.string.delete_confirm)
                .setPositiveButton(R.string.delete, (dialog, which) -> {
                    db.deleteCommanderDirective(directiveId);
                    finish();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private String text(EditText e) {
        return e.getText() == null ? "" : e.getText().toString().trim();
    }

    private String formatNumber(double v) {
        if (v == Math.floor(v)) return String.valueOf((long) v);
        return String.valueOf(v);
    }
}
