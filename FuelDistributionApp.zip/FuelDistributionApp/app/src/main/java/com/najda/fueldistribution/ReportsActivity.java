package com.najda.fueldistribution;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.najda.fueldistribution.models.CommanderDirective;
import com.najda.fueldistribution.models.Dispense;
import com.najda.fueldistribution.models.Recipient;
import com.najda.fueldistribution.utils.DateUtils;
import com.najda.fueldistribution.utils.PdfReportGenerator;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class ReportsActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private Spinner spinnerRecipient;
    private List<Recipient> recipients;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);

        db = DatabaseHelper.getInstance(this);
        spinnerRecipient = findViewById(R.id.spinnerRecipient);

        Button btnAll = findViewById(R.id.btnReportAllRecipients);
        Button btnMonthly = findViewById(R.id.btnReportMonthlySummary);
        Button btnCommander = findViewById(R.id.btnReportCommander);
        Button btnRecipient = findViewById(R.id.btnReportRecipient);

        btnAll.setOnClickListener(v -> runSafely(this::generateAllRecipientsReport));
        btnMonthly.setOnClickListener(v -> runSafely(this::generateMonthlySummaryReport));
        btnCommander.setOnClickListener(v -> runSafely(this::generateCommanderReport));
        btnRecipient.setOnClickListener(v -> runSafely(this::generateSelectedRecipientReport));
    }

    @Override
    protected void onResume() {
        super.onResume();
        recipients = db.getAllRecipients();
        String[] names = new String[recipients.size()];
        for (int i = 0; i < recipients.size(); i++) names[i] = recipients.get(i).getName();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names);
        spinnerRecipient.setAdapter(adapter);
    }

    private interface ReportAction {
        File generate() throws IOException;
    }

    private void runSafely(ReportAction action) {
        try {
            File file = action.generate();
            if (file == null) return;
            openPdf(file);
        } catch (IOException e) {
            Toast.makeText(this, "تعذر إنشاء التقرير: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private File generateAllRecipientsReport() throws IOException {
        List<Recipient> all = db.getAllRecipients();
        File f = PdfReportGenerator.generateAllRecipientsReport(this, all, db);
        Toast.makeText(this, R.string.pdf_saved, Toast.LENGTH_SHORT).show();
        return f;
    }

    private File generateMonthlySummaryReport() throws IOException {
        String monthPrefix = DateUtils.currentMonthPrefix();
        List<Dispense> monthDispenses = db.getAllDispensesForMonth(monthPrefix);
        double totalRegular = db.getTotalByTypeForMonth(monthPrefix, Dispense.TYPE_REGULAR);
        double totalCommander = db.getTotalByTypeForMonth(monthPrefix, Dispense.TYPE_COMMANDER);
        double totalEmergency = db.getTotalByTypeForMonth(monthPrefix, Dispense.TYPE_EMERGENCY);
        File f = PdfReportGenerator.generateMonthlySummaryReport(this, monthPrefix, monthDispenses,
                totalRegular, totalCommander, totalEmergency);
        Toast.makeText(this, R.string.pdf_saved, Toast.LENGTH_SHORT).show();
        return f;
    }

    private File generateCommanderReport() throws IOException {
        List<CommanderDirective> directives = db.getAllCommanderDirectives();
        double total = db.getCommanderTotal();
        File f = PdfReportGenerator.generateCommanderReport(this, directives, total);
        Toast.makeText(this, R.string.pdf_saved, Toast.LENGTH_SHORT).show();
        return f;
    }

    private File generateSelectedRecipientReport() throws IOException {
        int index = spinnerRecipient.getSelectedItemPosition();
        if (recipients == null || index < 0 || index >= recipients.size()) {
            Toast.makeText(this, R.string.no_results, Toast.LENGTH_SHORT).show();
            return null;
        }
        Recipient r = recipients.get(index);
        List<Dispense> history = db.getDispensesForRecipient(r.getId());
        double monthlyDispensed = db.getDispensedTotalForMonth(r.getId(), DateUtils.currentMonthPrefix(), 0);
        File f = PdfReportGenerator.generateRecipientReport(this, r, history, monthlyDispensed);
        Toast.makeText(this, R.string.pdf_saved, Toast.LENGTH_SHORT).show();
        return f;
    }

    private void openPdf(File file) {
        Uri uri = FileProvider.getUriForFile(this, "com.najda.fueldistribution.fileprovider", file);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(uri, "application/pdf");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "تم حفظ الملف في: " + file.getAbsolutePath(), Toast.LENGTH_LONG).show();
        }
    }
}
