package com.najda.fueldistribution.utils;

import android.content.Context;
import android.net.Uri;

import com.najda.fueldistribution.DatabaseHelper;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class BackupUtils {

    /** Copies the live database file into a timestamped local backup, and returns that file. */
    public static File backupToLocalFile(Context context) throws IOException {
        File dbFile = context.getDatabasePath(DatabaseHelper.getDbName());
        File dir = new File(context.getExternalFilesDir(null), "backups");
        if (!dir.exists()) dir.mkdirs();
        File outFile = new File(dir, "fuel_backup_" + DateUtils.today() + ".db");
        copyFile(new FileInputStream(dbFile), new FileOutputStream(outFile));
        return outFile;
    }

    /** Copies a local file's bytes out to a URI chosen by the user via Storage Access Framework. */
    public static void exportToUri(Context context, File source, Uri destUri) throws IOException {
        try (InputStream in = new FileInputStream(source);
             OutputStream out = context.getContentResolver().openOutputStream(destUri)) {
            copyStream(in, out);
        }
    }

    /** Restores the database from a user-chosen backup file (URI), overwriting the live database.
     *  The caller is responsible for closing any open DatabaseHelper connections beforehand
     *  and for restarting the app / relevant activities afterward. */
    public static void restoreFromUri(Context context, Uri sourceUri) throws IOException {
        File dbFile = context.getDatabasePath(DatabaseHelper.getDbName());
        File parent = dbFile.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        try (InputStream in = context.getContentResolver().openInputStream(sourceUri);
             OutputStream out = new FileOutputStream(dbFile)) {
            copyStream(in, out);
        }
    }

    private static void copyFile(InputStream in, OutputStream out) throws IOException {
        copyStream(in, out);
        in.close();
        out.close();
    }

    private static void copyStream(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[8192];
        int len;
        while ((len = in.read(buffer)) != -1) {
            out.write(buffer, 0, len);
        }
        out.flush();
    }
}
