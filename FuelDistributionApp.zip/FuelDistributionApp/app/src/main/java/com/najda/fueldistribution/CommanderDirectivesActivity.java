package com.najda.fueldistribution;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.najda.fueldistribution.adapters.CommanderDirectiveAdapter;
import com.najda.fueldistribution.models.CommanderDirective;

import java.util.List;
import java.util.Locale;

public class CommanderDirectivesActivity extends AppCompatActivity {

    public static final String EXTRA_DIRECTIVE_ID = "directive_id";

    private DatabaseHelper db;
    private CommanderDirectiveAdapter adapter;
    private RecyclerView recyclerView;
    private TextView tvEmpty, tvTotal;
    private EditText etSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_commander_directives);

        db = DatabaseHelper.getInstance(this);

        recyclerView = findViewById(R.id.recyclerView);
        tvEmpty = findViewById(R.id.tvEmpty);
        tvTotal = findViewById(R.id.tvTotal);
        etSearch = findViewById(R.id.etSearch);
        FloatingActionButton fabAdd = findViewById(R.id.fabAdd);

        adapter = new CommanderDirectiveAdapter(new CommanderDirectiveAdapter.OnItemActionListener() {
            @Override
            public void onClick(CommanderDirective directive) {
                Intent i = new Intent(CommanderDirectivesActivity.this, AddCommanderDirectiveActivity.class);
                i.putExtra(EXTRA_DIRECTIVE_ID, directive.getId());
                startActivity(i);
            }

            @Override
            public void onLongClick(CommanderDirective directive) {
                confirmDelete(directive);
            }
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        fabAdd.setOnClickListener(v -> startActivity(new Intent(this, AddCommanderDirectiveActivity.class)));

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                loadData(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData(etSearch.getText() != null ? etSearch.getText().toString() : "");
    }

    private void loadData(String query) {
        List<CommanderDirective> list = (query == null || query.trim().isEmpty())
                ? db.getAllCommanderDirectives()
                : db.searchCommanderDirectives(query.trim());
        adapter.setItems(list);
        boolean empty = list.isEmpty();
        tvEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(empty ? View.GONE : View.VISIBLE);

        double total = db.getCommanderTotal();
        tvTotal.setText(getString(R.string.total_dispensed_commander) + ": " +
                String.format(Locale.US, "%.0f", total) + " لتر");
    }

    private void confirmDelete(CommanderDirective d) {
        new AlertDialog.Builder(this)
                .setMessage(R.string.delete_confirm)
                .setPositiveButton(R.string.delete, (dialog, which) -> {
                    db.deleteCommanderDirective(d.getId());
                    loadData(etSearch.getText() != null ? etSearch.getText().toString() : "");
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }
}
