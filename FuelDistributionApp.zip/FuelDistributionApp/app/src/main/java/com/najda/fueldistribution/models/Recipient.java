package com.najda.fueldistribution.models;

public class Recipient {
    private long id;
    private String name;
    private String rank;
    private String unit;
    private double monthlyQuota;
    private String fuelType;
    private String phone;
    private String notes;

    public Recipient() {}

    public Recipient(long id, String name, String rank, String unit, double monthlyQuota,
                      String fuelType, String phone, String notes) {
        this.id = id;
        this.name = name;
        this.rank = rank;
        this.unit = unit;
        this.monthlyQuota = monthlyQuota;
        this.fuelType = fuelType;
        this.phone = phone;
        this.notes = notes;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getRank() { return rank; }
    public void setRank(String rank) { this.rank = rank; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public double getMonthlyQuota() { return monthlyQuota; }
    public void setMonthlyQuota(double monthlyQuota) { this.monthlyQuota = monthlyQuota; }

    public String getFuelType() { return fuelType; }
    public void setFuelType(String fuelType) { this.fuelType = fuelType; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
