package com.najda.fueldistribution;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.najda.fueldistribution.models.CommanderDirective;
import com.najda.fueldistribution.models.Dispense;
import com.najda.fueldistribution.models.Recipient;

import java.util.ArrayList;
import java.util.List;

/**
 * Central SQLite database helper for the fuel distribution system.
 * All reads/writes in the app go through this class.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "fuel_distribution.db";
    private static final int DB_VERSION = 1;

    // Recipients table
    public static final String TABLE_RECIPIENTS = "recipients";
    public static final String COL_R_ID = "_id";
    public static final String COL_R_NAME = "name";
    public static final String COL_R_RANK = "rank";
    public static final String COL_R_UNIT = "unit";
    public static final String COL_R_QUOTA = "monthly_quota";
    public static final String COL_R_FUEL_TYPE = "fuel_type";
    public static final String COL_R_PHONE = "phone";
    public static final String COL_R_NOTES = "notes";

    // Dispenses table
    public static final String TABLE_DISPENSES = "dispenses";
    public static final String COL_D_ID = "_id";
    public static final String COL_D_RECIPIENT_ID = "recipient_id";
    public static final String COL_D_DATE = "date";
    public static final String COL_D_QUANTITY = "quantity";
    public static final String COL_D_TYPE = "dispense_type";
    public static final String COL_D_DIRECTIVE_NO = "directive_number";
    public static final String COL_D_NOTES = "notes";

    // Commander directives table (independent section)
    public static final String TABLE_COMMANDER = "commander_directives";
    public static final String COL_C_ID = "_id";
    public static final String COL_C_DIRECTIVE_NO = "directive_number";
    public static final String COL_C_DATE = "date";
    public static final String COL_C_BENEFICIARY = "beneficiary_name";
    public static final String COL_C_QUANTITY = "quantity";
    public static final String COL_C_REASON = "reason";
    public static final String COL_C_NOTES = "notes";

    private static DatabaseHelper instance;

    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseHelper(context.getApplicationContext());
        }
        return instance;
    }

    public static String getDbName() {
        return DB_NAME;
    }

    private DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_RECIPIENTS + " (" +
                COL_R_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_R_NAME + " TEXT NOT NULL, " +
                COL_R_RANK + " TEXT, " +
                COL_R_UNIT + " TEXT, " +
                COL_R_QUOTA + " REAL NOT NULL DEFAULT 0, " +
                COL_R_FUEL_TYPE + " TEXT, " +
                COL_R_PHONE + " TEXT, " +
                COL_R_NOTES + " TEXT" +
                ");");

        db.execSQL("CREATE TABLE " + TABLE_DISPENSES + " (" +
                COL_D_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_D_RECIPIENT_ID + " INTEGER NOT NULL, " +
                COL_D_DATE + " TEXT NOT NULL, " +
                COL_D_QUANTITY + " REAL NOT NULL DEFAULT 0, " +
                COL_D_TYPE + " INTEGER NOT NULL DEFAULT 1, " +
                COL_D_DIRECTIVE_NO + " TEXT, " +
                COL_D_NOTES + " TEXT, " +
                "FOREIGN KEY(" + COL_D_RECIPIENT_ID + ") REFERENCES " + TABLE_RECIPIENTS + "(" + COL_R_ID + ") ON DELETE CASCADE" +
                ");");

        db.execSQL("CREATE TABLE " + TABLE_COMMANDER + " (" +
                COL_C_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_C_DIRECTIVE_NO + " TEXT, " +
                COL_C_DATE + " TEXT NOT NULL, " +
                COL_C_BENEFICIARY + " TEXT NOT NULL, " +
                COL_C_QUANTITY + " REAL NOT NULL DEFAULT 0, " +
                COL_C_REASON + " TEXT, " +
                COL_C_NOTES + " TEXT" +
                ");");

        db.execSQL("CREATE INDEX idx_dispenses_recipient ON " + TABLE_DISPENSES + "(" + COL_D_RECIPIENT_ID + ");");
        db.execSQL("CREATE INDEX idx_dispenses_date ON " + TABLE_DISPENSES + "(" + COL_D_DATE + ");");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // No prior versions yet; place migrations here as the schema evolves.
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    // ============================= RECIPIENTS =============================

    public long insertRecipient(Recipient r) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = recipientToValues(r);
        return db.insert(TABLE_RECIPIENTS, null, cv);
    }

    public int updateRecipient(Recipient r) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = recipientToValues(r);
        return db.update(TABLE_RECIPIENTS, cv, COL_R_ID + "=?", new String[]{String.valueOf(r.getId())});
    }

    public int deleteRecipient(long id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_DISPENSES, COL_D_RECIPIENT_ID + "=?", new String[]{String.valueOf(id)});
        return db.delete(TABLE_RECIPIENTS, COL_R_ID + "=?", new String[]{String.valueOf(id)});
    }

    private ContentValues recipientToValues(Recipient r) {
        ContentValues cv = new ContentValues();
        cv.put(COL_R_NAME, r.getName());
        cv.put(COL_R_RANK, r.getRank());
        cv.put(COL_R_UNIT, r.getUnit());
        cv.put(COL_R_QUOTA, r.getMonthlyQuota());
        cv.put(COL_R_FUEL_TYPE, r.getFuelType());
        cv.put(COL_R_PHONE, r.getPhone());
        cv.put(COL_R_NOTES, r.getNotes());
        return cv;
    }

    public List<Recipient> getAllRecipients() {
        List<Recipient> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_RECIPIENTS, null, null, null, null, null, COL_R_NAME + " ASC");
        while (c.moveToNext()) {
            list.add(cursorToRecipient(c));
        }
        c.close();
        return list;
    }

    public Recipient getRecipientById(long id) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_RECIPIENTS, null, COL_R_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null);
        Recipient r = null;
        if (c.moveToFirst()) {
            r = cursorToRecipient(c);
        }
        c.close();
        return r;
    }

    public List<Recipient> searchRecipients(String query) {
        List<Recipient> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String like = "%" + query + "%";
        Cursor c = db.query(TABLE_RECIPIENTS, null,
                COL_R_NAME + " LIKE ? OR " + COL_R_UNIT + " LIKE ? OR " + COL_R_RANK + " LIKE ?",
                new String[]{like, like, like}, null, null, COL_R_NAME + " ASC");
        while (c.moveToNext()) {
            list.add(cursorToRecipient(c));
        }
        c.close();
        return list;
    }

    private Recipient cursorToRecipient(Cursor c) {
        Recipient r = new Recipient();
        r.setId(c.getLong(c.getColumnIndexOrThrow(COL_R_ID)));
        r.setName(c.getString(c.getColumnIndexOrThrow(COL_R_NAME)));
        r.setRank(c.getString(c.getColumnIndexOrThrow(COL_R_RANK)));
        r.setUnit(c.getString(c.getColumnIndexOrThrow(COL_R_UNIT)));
        r.setMonthlyQuota(c.getDouble(c.getColumnIndexOrThrow(COL_R_QUOTA)));
        r.setFuelType(c.getString(c.getColumnIndexOrThrow(COL_R_FUEL_TYPE)));
        r.setPhone(c.getString(c.getColumnIndexOrThrow(COL_R_PHONE)));
        r.setNotes(c.getString(c.getColumnIndexOrThrow(COL_R_NOTES)));
        return r;
    }

    // ============================= DISPENSES =============================

    public long insertDispense(Dispense d) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_D_RECIPIENT_ID, d.getRecipientId());
        cv.put(COL_D_DATE, d.getDate());
        cv.put(COL_D_QUANTITY, d.getQuantity());
        cv.put(COL_D_TYPE, d.getDispenseType());
        cv.put(COL_D_DIRECTIVE_NO, d.getDirectiveNumber());
        cv.put(COL_D_NOTES, d.getNotes());
        return db.insert(TABLE_DISPENSES, null, cv);
    }

    public int deleteDispense(long id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(TABLE_DISPENSES, COL_D_ID + "=?", new String[]{String.valueOf(id)});
    }

    /** All dispense records for one recipient, most recent first. */
    public List<Dispense> getDispensesForRecipient(long recipientId) {
        List<Dispense> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_DISPENSES, null, COL_D_RECIPIENT_ID + "=?",
                new String[]{String.valueOf(recipientId)}, null, null, COL_D_DATE + " DESC, " + COL_D_ID + " DESC");
        while (c.moveToNext()) {
            list.add(cursorToDispense(c));
        }
        c.close();
        return list;
    }

    /** Sum of quantities dispensed to a recipient within a given yyyy-MM month prefix, for a specific type (or all types if type <= 0). */
    public double getDispensedTotalForMonth(long recipientId, String yearMonthPrefix, int type) {
        SQLiteDatabase db = getReadableDatabase();
        String where = COL_D_RECIPIENT_ID + "=? AND " + COL_D_DATE + " LIKE ?";
        List<String> args = new ArrayList<>();
        args.add(String.valueOf(recipientId));
        args.add(yearMonthPrefix + "%");
        if (type > 0) {
            where += " AND " + COL_D_TYPE + "=?";
            args.add(String.valueOf(type));
        }
        Cursor c = db.rawQuery("SELECT SUM(" + COL_D_QUANTITY + ") FROM " + TABLE_DISPENSES + " WHERE " + where,
                args.toArray(new String[0]));
        double total = 0;
        if (c.moveToFirst()) {
            total = c.getDouble(0);
        }
        c.close();
        return total;
    }

    /** All dispenses across all recipients within a yyyy-MM month, joined with recipient name. */
    public List<Dispense> getAllDispensesForMonth(String yearMonthPrefix) {
        List<Dispense> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT d.*, r." + COL_R_NAME + " AS recipient_name FROM " + TABLE_DISPENSES + " d " +
                "LEFT JOIN " + TABLE_RECIPIENTS + " r ON d." + COL_D_RECIPIENT_ID + " = r." + COL_R_ID +
                " WHERE d." + COL_D_DATE + " LIKE ? ORDER BY d." + COL_D_DATE + " DESC";
        Cursor c = db.rawQuery(sql, new String[]{yearMonthPrefix + "%"});
        while (c.moveToNext()) {
            Dispense d = cursorToDispense(c);
            d.setRecipientName(c.getString(c.getColumnIndexOrThrow("recipient_name")));
            list.add(d);
        }
        c.close();
        return list;
    }

    public double getTotalByTypeForMonth(String yearMonthPrefix, int type) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT SUM(" + COL_D_QUANTITY + ") FROM " + TABLE_DISPENSES +
                        " WHERE " + COL_D_DATE + " LIKE ? AND " + COL_D_TYPE + "=?",
                new String[]{yearMonthPrefix + "%", String.valueOf(type)});
        double total = 0;
        if (c.moveToFirst()) total = c.getDouble(0);
        c.close();
        return total;
    }

    /** Searches dispenses by recipient name, directive number, or date/month text. */
    public List<Dispense> searchDispenses(String query) {
        List<Dispense> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String like = "%" + query + "%";
        String sql = "SELECT d.*, r." + COL_R_NAME + " AS recipient_name FROM " + TABLE_DISPENSES + " d " +
                "LEFT JOIN " + TABLE_RECIPIENTS + " r ON d." + COL_D_RECIPIENT_ID + " = r." + COL_R_ID +
                " WHERE d." + COL_D_DIRECTIVE_NO + " LIKE ? OR d." + COL_D_DATE + " LIKE ? OR r." + COL_R_NAME + " LIKE ?" +
                " ORDER BY d." + COL_D_DATE + " DESC LIMIT 100";
        Cursor c = db.rawQuery(sql, new String[]{like, like, like});
        while (c.moveToNext()) {
            Dispense d = cursorToDispense(c);
            d.setRecipientName(c.getString(c.getColumnIndexOrThrow("recipient_name")));
            list.add(d);
        }
        c.close();
        return list;
    }

    private Dispense cursorToDispense(Cursor c) {
        Dispense d = new Dispense();
        d.setId(c.getLong(c.getColumnIndexOrThrow(COL_D_ID)));
        d.setRecipientId(c.getLong(c.getColumnIndexOrThrow(COL_D_RECIPIENT_ID)));
        d.setDate(c.getString(c.getColumnIndexOrThrow(COL_D_DATE)));
        d.setQuantity(c.getDouble(c.getColumnIndexOrThrow(COL_D_QUANTITY)));
        d.setDispenseType(c.getInt(c.getColumnIndexOrThrow(COL_D_TYPE)));
        d.setDirectiveNumber(c.getString(c.getColumnIndexOrThrow(COL_D_DIRECTIVE_NO)));
        d.setNotes(c.getString(c.getColumnIndexOrThrow(COL_D_NOTES)));
        return d;
    }

    // ========================= COMMANDER DIRECTIVES =========================

    public long insertCommanderDirective(CommanderDirective d) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = commanderToValues(d);
        return db.insert(TABLE_COMMANDER, null, cv);
    }

    public int updateCommanderDirective(CommanderDirective d) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = commanderToValues(d);
        return db.update(TABLE_COMMANDER, cv, COL_C_ID + "=?", new String[]{String.valueOf(d.getId())});
    }

    public int deleteCommanderDirective(long id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(TABLE_COMMANDER, COL_C_ID + "=?", new String[]{String.valueOf(id)});
    }

    private ContentValues commanderToValues(CommanderDirective d) {
        ContentValues cv = new ContentValues();
        cv.put(COL_C_DIRECTIVE_NO, d.getDirectiveNumber());
        cv.put(COL_C_DATE, d.getDate());
        cv.put(COL_C_BENEFICIARY, d.getBeneficiaryName());
        cv.put(COL_C_QUANTITY, d.getQuantity());
        cv.put(COL_C_REASON, d.getReason());
        cv.put(COL_C_NOTES, d.getNotes());
        return cv;
    }

    public List<CommanderDirective> getAllCommanderDirectives() {
        List<CommanderDirective> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_COMMANDER, null, null, null, null, null, COL_C_DATE + " DESC");
        while (c.moveToNext()) {
            list.add(cursorToCommander(c));
        }
        c.close();
        return list;
    }

    public List<CommanderDirective> searchCommanderDirectives(String query) {
        List<CommanderDirective> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String like = "%" + query + "%";
        Cursor c = db.query(TABLE_COMMANDER, null,
                COL_C_BENEFICIARY + " LIKE ? OR " + COL_C_DIRECTIVE_NO + " LIKE ?",
                new String[]{like, like}, null, null, COL_C_DATE + " DESC");
        while (c.moveToNext()) {
            list.add(cursorToCommander(c));
        }
        c.close();
        return list;
    }

    public double getCommanderTotal() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT SUM(" + COL_C_QUANTITY + ") FROM " + TABLE_COMMANDER, null);
        double total = 0;
        if (c.moveToFirst()) total = c.getDouble(0);
        c.close();
        return total;
    }

    private CommanderDirective cursorToCommander(Cursor c) {
        CommanderDirective d = new CommanderDirective();
        d.setId(c.getLong(c.getColumnIndexOrThrow(COL_C_ID)));
        d.setDirectiveNumber(c.getString(c.getColumnIndexOrThrow(COL_C_DIRECTIVE_NO)));
        d.setDate(c.getString(c.getColumnIndexOrThrow(COL_C_DATE)));
        d.setBeneficiaryName(c.getString(c.getColumnIndexOrThrow(COL_C_BENEFICIARY)));
        d.setQuantity(c.getDouble(c.getColumnIndexOrThrow(COL_C_QUANTITY)));
        d.setReason(c.getString(c.getColumnIndexOrThrow(COL_C_REASON)));
        d.setNotes(c.getString(c.getColumnIndexOrThrow(COL_C_NOTES)));
        return d;
    }
}
