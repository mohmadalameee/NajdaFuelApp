package com.najda.fueldistribution.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.najda.fueldistribution.R;
import com.najda.fueldistribution.models.Dispense;

import java.util.ArrayList;
import java.util.List;

public class DispenseAdapter extends RecyclerView.Adapter<DispenseAdapter.ViewHolder> {

    public interface OnLongClickListener {
        void onLongClick(Dispense dispense);
    }

    private List<Dispense> items = new ArrayList<>();
    private final boolean showRecipientName;
    private final OnLongClickListener longClickListener;

    public DispenseAdapter(boolean showRecipientName, OnLongClickListener longClickListener) {
        this.showRecipientName = showRecipientName;
        this.longClickListener = longClickListener;
    }

    public void setItems(List<Dispense> items) {
        this.items = items;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_dispense, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Dispense d = items.get(position);
        holder.tvDate.setText(d.getDate());
        holder.tvQuantity.setText(formatNumber(d.getQuantity()) + " لتر");

        String typeAndRecipient = Dispense.typeLabel(d.getDispenseType());
        if (showRecipientName && d.getRecipientName() != null) {
            typeAndRecipient = d.getRecipientName() + " — " + typeAndRecipient;
        }
        holder.tvTypeAndRecipient.setText(typeAndRecipient);

        if (d.getDirectiveNumber() != null && !d.getDirectiveNumber().isEmpty()) {
            holder.tvDirective.setText("رقم التوجيه: " + d.getDirectiveNumber());
            holder.tvDirective.setVisibility(View.VISIBLE);
        } else {
            holder.tvDirective.setVisibility(View.GONE);
        }

        holder.itemView.setOnLongClickListener(v -> {
            if (longClickListener != null) {
                longClickListener.onLongClick(d);
                return true;
            }
            return false;
        });
    }

    private String formatNumber(double v) {
        if (v == Math.floor(v)) return String.valueOf((long) v);
        return String.valueOf(v);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvDate, tvQuantity, tvTypeAndRecipient, tvDirective;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvQuantity = itemView.findViewById(R.id.tvQuantity);
            tvTypeAndRecipient = itemView.findViewById(R.id.tvTypeAndRecipient);
            tvDirective = itemView.findViewById(R.id.tvDirective);
        }
    }
}
