package com.najda.fueldistribution;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.najda.fueldistribution.adapters.DispenseAdapter;
import com.najda.fueldistribution.models.Dispense;
import com.najda.fueldistribution.models.Recipient;
import com.najda.fueldistribution.utils.DateUtils;

import java.util.List;
import java.util.Locale;

public class RecipientDetailActivity extends AppCompatActivity {

    public static final String EXTRA_RECIPIENT_ID = RecipientsActivity.EXTRA_RECIPIENT_ID;

    private DatabaseHelper db;
    private long recipientId;
    private Recipient recipient;

    private TextView tvRecipientName, tvRecipientMeta, tvMonthLabel, tvQuotaLine, tvDispensedLine, tvRemainingLine, tvPercentageLine;
    private DispenseAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipient_detail);

        db = DatabaseHelper.getInstance(this);
        recipientId = getIntent().getLongExtra(EXTRA_RECIPIENT_ID, -1);

        tvRecipientName = findViewById(R.id.tvRecipientName);
        tvRecipientMeta = findViewById(R.id.tvRecipientMeta);
        tvMonthLabel = findViewById(R.id.tvMonthLabel);
        tvQuotaLine = findViewById(R.id.tvQuotaLine);
        tvDispensedLine = findViewById(R.id.tvDispensedLine);
        tvRemainingLine = findViewById(R.id.tvRemainingLine);
        tvPercentageLine = findViewById(R.id.tvPercentageLine);

        RecyclerView recyclerHistory = findViewById(R.id.recyclerHistory);
        adapter = new DispenseAdapter(false, dispense -> confirmDeleteDispense(dispense));
        recyclerHistory.setLayoutManager(new LinearLayoutManager(this));
        recyclerHistory.setAdapter(adapter);

        setupButtons();
    }

    private void setupButtons() {
        Button btnEditRecipient = findViewById(R.id.btnEditRecipient);
        btnEditRecipient.setOnClickListener(v -> {
            Intent i = new Intent(this, AddEditRecipientActivity.class);
            i.putExtra(RecipientsActivity.EXTRA_RECIPIENT_ID, recipientId);
            startActivity(i);
        });

        FloatingActionButton fabAddDispense = findViewById(R.id.fabAddDispense);
        fabAddDispense.setOnClickListener(v -> {
            Intent i = new Intent(this, AddDispenseActivity.class);
            i.putExtra(RecipientsActivity.EXTRA_RECIPIENT_ID, recipientId);
            startActivity(i);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData();
    }

    private void loadData() {
        recipient = db.getRecipientById(recipientId);
        if (recipient == null) {
            Toast.makeText(this, R.string.no_results, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        tvRecipientName.setText(recipient.getName());
        String meta = (recipient.getRank() == null ? "" : recipient.getRank()) +
                (recipient.getUnit() != null && !recipient.getUnit().isEmpty() ? " - " + recipient.getUnit() : "");
        tvRecipientMeta.setText(meta);

        String monthPrefix = DateUtils.currentMonthPrefix();
        tvMonthLabel.setText(DateUtils.monthLabel(monthPrefix));

        double quota = recipient.getMonthlyQuota();
        double dispensed = db.getDispensedTotalForMonth(recipientId, monthPrefix, 0);
        double remaining = quota - dispensed;
        double percentage = quota > 0 ? (dispensed / quota) * 100.0 : 0;

        tvQuotaLine.setText(getString(R.string.monthly_quota) + ": " + fmt(quota) + " لتر");
        tvDispensedLine.setText(getString(R.string.dispensed_this_month) + ": " + fmt(dispensed) + " لتر");
        tvRemainingLine.setText(getString(R.string.remaining) + ": " + fmt(remaining) + " لتر");
        tvPercentageLine.setText(getString(R.string.percentage) + ": " + String.format(Locale.US, "%.0f", percentage) + "%");

        List<Dispense> history = db.getDispensesForRecipient(recipientId);
        adapter.setItems(history);
    }

    private void confirmDeleteDispense(Dispense d) {
        new AlertDialog.Builder(this)
                .setMessage(R.string.delete_confirm)
                .setPositiveButton(R.string.delete, (dialog, which) -> {
                    db.deleteDispense(d.getId());
                    loadData();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private String fmt(double v) {
        if (v == Math.floor(v)) return String.valueOf((long) v);
        return String.format(Locale.US, "%.1f", v);
    }
}
