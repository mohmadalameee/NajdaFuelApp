package com.najda.fueldistribution.utils;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;

import com.najda.fueldistribution.DatabaseHelper;
import com.najda.fueldistribution.models.CommanderDirective;
import com.najda.fueldistribution.models.Dispense;
import com.najda.fueldistribution.models.Recipient;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Locale;

/**
 * Builds official-format PDF reports for the fuel distribution system using
 * Android's built-in PdfDocument/Canvas APIs (no external PDF library required,
 * so the app has no network or extra-dependency needs at report time).
 *
 * Layout follows the requested official template:
 *  - Center: الجمهورية اليمنية
 *  - Right: وزارة الداخلية / الإمداد والتموين / قوات النجدة - محافظة ...
 *  - Left: التاريخ
 *  - Body: data table
 *  - Footer: مدير التموين (right) / القائد (left) signature lines
 */
public class PdfReportGenerator {

    private static final int PAGE_WIDTH = 595;  // A4 at 72dpi
    private static final int PAGE_HEIGHT = 842;
    private static final int MARGIN = 36;
    private static final int HEADER_HEIGHT = 110;
    private static final int FOOTER_HEIGHT = 90;
    private static final int ROW_HEIGHT = 26;

    /** Governorate name shown in the header. Edit here if the unit's governorate changes. */
    public static String GOVERNORATE = "مأرب";

    public interface RowRenderer<T> {
        String[] toRow(T item);
    }

    // ---------------------------------------------------------------- Public report builders

    public static File generateAllRecipientsReport(Context context, List<Recipient> recipients,
                                                     DatabaseHelper db) throws IOException {
        String monthPrefix = DateUtils.currentMonthPrefix();
        String[] headers = {"م", "الاسم", "الرتبة/الوحدة", "المقرر", "المصروف", "المتبقي", "النسبة"};
        float[] widths = {0.06f, 0.26f, 0.24f, 0.12f, 0.12f, 0.10f, 0.10f};

        String[][] rows = new String[recipients.size()][];
        for (int i = 0; i < recipients.size(); i++) {
            Recipient r = recipients.get(i);
            double dispensed = db.getDispensedTotalForMonth(r.getId(), monthPrefix, 0);
            double remaining = r.getMonthlyQuota() - dispensed;
            double pct = r.getMonthlyQuota() > 0 ? (dispensed / r.getMonthlyQuota()) * 100 : 0;
            rows[i] = new String[]{
                    String.valueOf(i + 1),
                    r.getName(),
                    join(r.getRank(), r.getUnit()),
                    fmt(r.getMonthlyQuota()),
                    fmt(dispensed),
                    fmt(remaining),
                    String.format(Locale.US, "%.0f%%", pct)
            };
        }

        return buildReport(context, "تقرير جميع المستلمين - " + DateUtils.monthLabel(monthPrefix),
                headers, widths, rows, "report_all_recipients");
    }

    public static File generateRecipientReport(Context context, Recipient r, List<Dispense> dispenses,
                                                double monthlyDispensed) throws IOException {
        String[] headers = {"م", "التاريخ", "الكمية", "نوع الصرف", "رقم التوجيه"};
        float[] widths = {0.08f, 0.20f, 0.16f, 0.36f, 0.20f};

        String[][] rows = new String[dispenses.size()][];
        for (int i = 0; i < dispenses.size(); i++) {
            Dispense d = dispenses.get(i);
            rows[i] = new String[]{
                    String.valueOf(i + 1),
                    d.getDate(),
                    fmt(d.getQuantity()),
                    Dispense.typeLabel(d.getDispenseType()),
                    d.getDirectiveNumber() == null ? "" : d.getDirectiveNumber()
            };
        }

        double remaining = r.getMonthlyQuota() - monthlyDispensed;
        double pct = r.getMonthlyQuota() > 0 ? (monthlyDispensed / r.getMonthlyQuota()) * 100 : 0;
        String subtitle = r.getName() + "   |   المقرر: " + fmt(r.getMonthlyQuota()) +
                "   المصروف: " + fmt(monthlyDispensed) +
                "   المتبقي: " + fmt(remaining) +
                "   النسبة: " + String.format(Locale.US, "%.0f%%", pct);

        return buildReport(context, "تقرير صرف المستلم", subtitle, headers, widths, rows,
                "report_recipient_" + r.getId());
    }

    public static File generateCommanderReport(Context context, List<CommanderDirective> directives,
                                                double total) throws IOException {
        String[] headers = {"م", "التاريخ", "رقم التوجيه", "المستفيد", "الكمية", "السبب"};
        float[] widths = {0.06f, 0.14f, 0.16f, 0.24f, 0.12f, 0.28f};

        String[][] rows = new String[directives.size()][];
        for (int i = 0; i < directives.size(); i++) {
            CommanderDirective d = directives.get(i);
            rows[i] = new String[]{
                    String.valueOf(i + 1),
                    d.getDate(),
                    d.getDirectiveNumber() == null ? "" : d.getDirectiveNumber(),
                    d.getBeneficiaryName(),
                    fmt(d.getQuantity()),
                    d.getReason() == null ? "" : d.getReason()
            };
        }

        String subtitle = "إجمالي الصرف بتوجيه القائد العام: " + fmt(total) + " لتر";
        return buildReport(context, "تقرير توجيهات القائد العام", subtitle, headers, widths, rows,
                "report_commander");
    }

    public static File generateMonthlySummaryReport(Context context, String monthPrefix,
                                                      List<Dispense> monthDispenses,
                                                      double totalRegular, double totalCommander,
                                                      double totalEmergency) throws IOException {
        String[] headers = {"م", "التاريخ", "المستلم", "الكمية", "نوع الصرف", "رقم التوجيه"};
        float[] widths = {0.06f, 0.14f, 0.24f, 0.12f, 0.26f, 0.18f};

        String[][] rows = new String[monthDispenses.size()][];
        for (int i = 0; i < monthDispenses.size(); i++) {
            Dispense d = monthDispenses.get(i);
            rows[i] = new String[]{
                    String.valueOf(i + 1),
                    d.getDate(),
                    d.getRecipientName() == null ? "" : d.getRecipientName(),
                    fmt(d.getQuantity()),
                    Dispense.typeLabel(d.getDispenseType()),
                    d.getDirectiveNumber() == null ? "" : d.getDirectiveNumber()
            };
        }

        String subtitle = "إجمالي الشهر: " + fmt(totalRegular + totalCommander + totalEmergency) + " لتر   |   " +
                "المقرر الشهري: " + fmt(totalRegular) + "   |   " +
                "القائد العام: " + fmt(totalCommander) + "   |   " +
                "الطارئ: " + fmt(totalEmergency);

        return buildReport(context, "تقرير الملخص الشهري - " + DateUtils.monthLabel(monthPrefix),
                subtitle, headers, widths, rows, "report_monthly_" + monthPrefix);
    }

    // ---------------------------------------------------------------- Core rendering engine

    private static File buildReport(Context context, String title, String[] headers, float[] widths,
                                     String[][] rows, String fileNamePrefix) throws IOException {
        return buildReport(context, title, null, headers, widths, rows, fileNamePrefix);
    }

    private static File buildReport(Context context, String title, String subtitle, String[] headers,
                                     float[] widths, String[][] rows, String fileNamePrefix) throws IOException {
        PdfDocument document = new PdfDocument();
        Paint paint = new Paint();
        paint.setAntiAlias(true);

        int pageNumber = 1;
        PdfDocument.Page page = startPage(document, pageNumber, paint, title, subtitle);
        Canvas canvas = page.getCanvas();
        int y = HEADER_HEIGHT + (subtitle != null ? 20 : 0);

        y = drawTableHeader(canvas, paint, headers, widths, y);

        for (String[] row : rows) {
            if (y + ROW_HEIGHT > PAGE_HEIGHT - FOOTER_HEIGHT) {
                document.finishPage(page);
                pageNumber++;
                page = startPage(document, pageNumber, paint, title, subtitle);
                canvas = page.getCanvas();
                y = HEADER_HEIGHT + (subtitle != null ? 20 : 0);
                y = drawTableHeader(canvas, paint, headers, widths, y);
            }
            y = drawTableRow(canvas, paint, row, widths, y);
        }

        drawFooter(canvas, paint);
        document.finishPage(page);

        File dir = new File(context.getExternalFilesDir(null), "reports");
        if (!dir.exists()) dir.mkdirs();
        String fileName = fileNamePrefix + "_" + DateUtils.today() + ".pdf";
        File outFile = new File(dir, fileName);
        try (FileOutputStream fos = new FileOutputStream(outFile)) {
            document.writeTo(fos);
        }
        document.close();
        return outFile;
    }

    private static PdfDocument.Page startPage(PdfDocument document, int pageNumber, Paint paint,
                                               String title, String subtitle) {
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create();
        PdfDocument.Page page = document.startPage(pageInfo);
        drawHeader(page.getCanvas(), paint, title, subtitle);
        return page;
    }

    private static void drawHeader(Canvas canvas, Paint paint, String title, String subtitle) {
        int right = PAGE_WIDTH - MARGIN;
        int left = MARGIN;
        int centerX = PAGE_WIDTH / 2;

        // الجمهورية اليمنية - centered
        paint.setColor(Color.BLACK);
        paint.setTextSize(16);
        paint.setFakeBoldText(true);
        paint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText("الجمهورية اليمنية", centerX, 30, paint);

        // Right block: ministry / department / unit-governorate
        paint.setTextSize(11);
        paint.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText("وزارة الداخلية", right, 50, paint);
        canvas.drawText("الإمداد والتموين", right, 66, paint);
        canvas.drawText("قوات النجدة - محافظة " + PdfReportGenerator.GOVERNORATE, right, 82, paint);

        // Left block: date
        paint.setTextAlign(Paint.Align.LEFT);
        canvas.drawText("التاريخ: " + DateUtils.today(), left, 50, paint);

        // divider line
        paint.setFakeBoldText(false);
        paint.setStrokeWidth(1f);
        canvas.drawLine(MARGIN, 92, PAGE_WIDTH - MARGIN, 92, paint);

        // Report title
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(14);
        paint.setFakeBoldText(true);
        canvas.drawText(title, centerX, 108, paint);

        if (subtitle != null) {
            paint.setTextSize(11);
            paint.setFakeBoldText(false);
            canvas.drawText(subtitle, centerX, 124, paint);
        }
        paint.setFakeBoldText(false);
    }

    /** Draws table header row (right-to-left columns) and returns the new y offset. */
    private static int drawTableHeader(Canvas canvas, Paint paint, String[] headers, float[] widths, int y) {
        int tableWidth = PAGE_WIDTH - 2 * MARGIN;
        paint.setColor(Color.rgb(11, 61, 46)); // primary
        canvas.drawRect(MARGIN, y, PAGE_WIDTH - MARGIN, y + ROW_HEIGHT, paint);

        paint.setColor(Color.WHITE);
        paint.setTextSize(11);
        paint.setFakeBoldText(true);
        drawRowCells(canvas, paint, headers, widths, tableWidth, y);

        paint.setColor(Color.BLACK);
        paint.setFakeBoldText(false);
        return y + ROW_HEIGHT;
    }

    private static int drawTableRow(Canvas canvas, Paint paint, String[] row, float[] widths, int y) {
        int tableWidth = PAGE_WIDTH - 2 * MARGIN;
        paint.setColor(Color.WHITE);
        paint.setTextSize(10.5f);
        drawRowCells(canvas, paint, row, widths, tableWidth, y);

        paint.setColor(Color.rgb(221, 221, 221));
        paint.setStrokeWidth(0.5f);
        canvas.drawLine(MARGIN, y + ROW_HEIGHT, PAGE_WIDTH - MARGIN, y + ROW_HEIGHT, paint);
        paint.setColor(Color.BLACK);
        return y + ROW_HEIGHT;
    }

    /** Draws one row's cells right-to-left; column 0 is rightmost, matching Arabic reading order. */
    private static void drawRowCells(Canvas canvas, Paint paint, String[] cells, float[] widths,
                                      int tableWidth, int y) {
        float xRight = PAGE_WIDTH - MARGIN;
        int textY = y + ROW_HEIGHT - 8;
        paint.setTextAlign(Paint.Align.RIGHT);
        for (int i = 0; i < cells.length; i++) {
            float colWidth = widths[i] * tableWidth;
            String text = truncate(paint, cells[i] == null ? "" : cells[i], colWidth - 8);
            canvas.drawText(text, xRight - 4, textY, paint);
            xRight -= colWidth;
        }
    }

    private static String truncate(Paint paint, String text, float maxWidth) {
        if (paint.measureText(text) <= maxWidth) return text;
        String ellipsis = "...";
        StringBuilder sb = new StringBuilder(text);
        while (sb.length() > 0 && paint.measureText(sb + ellipsis) > maxWidth) {
            sb.deleteCharAt(sb.length() - 1);
        }
        return sb + ellipsis;
    }

    private static void drawFooter(Canvas canvas, Paint paint) {
        int y = PAGE_HEIGHT - FOOTER_HEIGHT + 20;
        paint.setColor(Color.BLACK);
        paint.setTextSize(12);
        paint.setFakeBoldText(true);

        paint.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText("مدير التموين", PAGE_WIDTH - MARGIN, y, paint);
        paint.setTextAlign(Paint.Align.LEFT);
        canvas.drawText("القائد", MARGIN, y, paint);

        paint.setFakeBoldText(false);
        paint.setTextSize(11);
        y += 30;
        paint.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText("التوقيع: ______________", PAGE_WIDTH - MARGIN, y, paint);
        paint.setTextAlign(Paint.Align.LEFT);
        canvas.drawText("التوقيع: ______________", MARGIN, y, paint);
    }

    /**
     * Generates the official fuel-plan layout without creating the removed
     * daily-operations table. Monthly rows come directly from the existing
     * recipient/dispense data; the out-of-plan commander table is preserved
     * as a separate section with its original values and total.
     */
    public static File generateFuelPlanReport(Context context, String monthPrefix,
                                               List<Recipient> recipients,
                                               List<CommanderDirective> directives,
                                               DatabaseHelper db) throws IOException {
        final int width = 842;   // A4 landscape at 72 dpi
        final int height = 595;
        final int margin = 43;   // approximately 1.5 cm
        final int rowHeight = 25;
        final int footerTop = height - 78;
        final String title = "كشف خطة البترول والوقود لقيادة قوات الأمن الخاصة";
        PdfDocument document = new PdfDocument();
        int pageNumber = 1;
        LandscapePage page = openLandscapePage(document, 1, width, height, margin,
                title, monthPrefix);

        page.y = drawLandscapeSectionTitle(page.canvas, page.y,
                "ثانيًا: كشف الإجمالي الشهري النهائي", width, margin);
        String[] monthlyHeaders = {"م", "البيان", "المقرر", "المصروف", "المتبقي",
                "الاستهلاك", "الحالة", "مقدار التجاوز"};
        float[] monthlyWidths = {0.06f, 0.23f, 0.11f, 0.11f, 0.11f, 0.11f, 0.12f, 0.15f};
        page.y = drawLandscapeHeader(page.canvas, monthlyHeaders, monthlyWidths,
                page.y, width, margin, rowHeight);

        double totalQuota = 0;
        double totalDispensed = 0;
        for (int i = 0; i < recipients.size(); i++) {
            Recipient recipient = recipients.get(i);
            double quota = recipient.getMonthlyQuota();
            double dispensed = db.getDispensedTotalForMonth(recipient.getId(), monthPrefix, 0);
            double remaining = quota - dispensed;
            double consumption = quota > 0 ? (dispensed / quota) * 100 : 0;
            totalQuota += quota;
            totalDispensed += dispensed;
            String statement = join(recipient.getName(), recipient.getUnit());
            String[] row = {String.valueOf(i + 1), statement, fmt(quota), fmt(dispensed),
                    fmt(remaining), String.format(Locale.US, "%.0f%%", consumption),
                    dispensed > quota ? "متجاوز" : "ضمن الخطة", ""};
            if (page.y + rowHeight > footerTop) {
                document.finishPage(page.page);
                page = openLandscapePage(document, ++pageNumber, width,
                        height, margin, title, monthPrefix);
                page.y = drawLandscapeSectionTitle(page.canvas, page.y,
                        "ثانيًا: كشف الإجمالي الشهري النهائي", width, margin);
                page.y = drawLandscapeHeader(page.canvas, monthlyHeaders, monthlyWidths,
                        page.y, width, margin, rowHeight);
            }
            page.y = drawLandscapeRow(page.canvas, row, monthlyWidths, page.y, width, margin, rowHeight);
        }

        double totalRemaining = totalQuota - totalDispensed;
        double totalConsumption = totalQuota > 0 ? (totalDispensed / totalQuota) * 100 : 0;
        String[] totalRow = {"", "الإجمالي الشهري النهائي", fmt(totalQuota), fmt(totalDispensed),
                fmt(totalRemaining), String.format(Locale.US, "%.0f%%", totalConsumption), "", ""};
        if (page.y + rowHeight > footerTop) {
            document.finishPage(page.page);
            page = openLandscapePage(document, ++pageNumber, width,
                    height, margin, title, monthPrefix);
            page.y = drawLandscapeSectionTitle(page.canvas, page.y,
                    "ثانيًا: كشف الإجمالي الشهري النهائي", width, margin);
            page.y = drawLandscapeHeader(page.canvas, monthlyHeaders, monthlyWidths,
                    page.y, width, margin, rowHeight);
        }
        page.y = drawLandscapeRow(page.canvas, totalRow, monthlyWidths, page.y, width, margin, rowHeight);

        page.y += 18;
        page.y = drawLandscapeSectionTitle(page.canvas, page.y,
                "أولًا: كشف توجيهات القائد — خارج الخطة", width, margin);
        String[] directiveHeaders = {"م", "التاريخ", "رقم التوجيه", "المستفيد", "الكمية", "السبب"};
        float[] directiveWidths = {0.06f, 0.16f, 0.17f, 0.25f, 0.12f, 0.24f};
        page.y = drawLandscapeHeader(page.canvas, directiveHeaders, directiveWidths,
                page.y, width, margin, rowHeight);
        double directiveTotal = 0;
        for (int i = 0; i < directives.size(); i++) {
            CommanderDirective directive = directives.get(i);
            directiveTotal += directive.getQuantity();
            String[] row = {String.valueOf(i + 1), safe(directive.getDate()),
                    safe(directive.getDirectiveNumber()), safe(directive.getBeneficiaryName()),
                    fmt(directive.getQuantity()), safe(directive.getReason())};
            if (page.y + rowHeight > footerTop) {
                document.finishPage(page.page);
                page = openLandscapePage(document, ++pageNumber, width,
                        height, margin, title, monthPrefix);
                page.y = drawLandscapeSectionTitle(page.canvas, page.y,
                        "أولًا: كشف توجيهات القائد — خارج الخطة", width, margin);
                page.y = drawLandscapeHeader(page.canvas, directiveHeaders, directiveWidths,
                        page.y, width, margin, rowHeight);
            }
            page.y = drawLandscapeRow(page.canvas, row, directiveWidths, page.y, width, margin, rowHeight);
        }
        String[] directiveTotalRow = {"", "", "", "إجمالي توجيهات القائد", fmt(directiveTotal), ""};
        if (page.y + rowHeight <= footerTop) {
            page.y = drawLandscapeRow(page.canvas, directiveTotalRow, directiveWidths,
                    page.y, width, margin, rowHeight);
        }
        drawLandscapeSignatures(page.canvas, width, height, margin);
        document.finishPage(page.page);

        File dir = new File(context.getExternalFilesDir(null), "reports");
        if (!dir.exists()) dir.mkdirs();
        File outFile = new File(dir, "fuel_plan_" + monthPrefix + ".pdf");
        try (FileOutputStream fos = new FileOutputStream(outFile)) {
            document.writeTo(fos);
        }
        document.close();
        return outFile;
    }

    private static class LandscapePage {
        final PdfDocument.Page page;
        final Canvas canvas;
        int y;
        LandscapePage(PdfDocument.Page page, Canvas canvas, int y) {
            this.page = page;
            this.canvas = canvas;
            this.y = y;
        }
    }

    private static LandscapePage openLandscapePage(PdfDocument document, int number, int width,
                                                    int height, int margin, String title,
                                                    String monthPrefix) {
        PdfDocument.Page page = document.startPage(new PdfDocument.PageInfo.Builder(width, height, number).create());
        Canvas canvas = page.getCanvas();
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.BLACK);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTextSize(15);
        paint.setFakeBoldText(true);
        canvas.drawText("الجمهورية اليمنية", width / 2f, 27, paint);
        paint.setTextSize(11);
        canvas.drawText("كشف خطة البترول والوقود لقيادة قوات الأمن الخاصة", width / 2f, 46, paint);
        paint.setTextSize(9);
        paint.setFakeBoldText(false);
        canvas.drawText("رقم الخطة: __________   السنة: ________   الجهة: __________________   الشهر: ________",
                width / 2f, 63, paint);
        canvas.drawLine(margin, 73, width - margin, 73, paint);
        return new LandscapePage(page, canvas, 86);
    }

    private static int drawLandscapeSectionTitle(Canvas canvas, int y, String title,
                                                   int width, int margin) {
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.BLACK);
        paint.setTextAlign(Paint.Align.RIGHT);
        paint.setTextSize(11);
        paint.setFakeBoldText(true);
        canvas.drawText(title, width - margin, y, paint);
        return y + 18;
    }

    private static int drawLandscapeHeader(Canvas canvas, String[] cells, float[] widths, int y,
                                           int width, int margin, int rowHeight) {
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.rgb(11, 61, 46));
        canvas.drawRect(margin, y, width - margin, y + rowHeight, paint);
        paint.setColor(Color.WHITE);
        paint.setTextSize(9);
        paint.setFakeBoldText(true);
        drawLandscapeCells(canvas, paint, cells, widths, width - 2 * margin, margin, y, rowHeight);
        return y + rowHeight;
    }

    private static int drawLandscapeRow(Canvas canvas, String[] cells, float[] widths, int y,
                                        int width, int margin, int rowHeight) {
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.WHITE);
        canvas.drawRect(margin, y, width - margin, y + rowHeight, paint);
        paint.setColor(Color.BLACK);
        paint.setTextSize(8.5f);
        paint.setFakeBoldText(false);
        drawLandscapeCells(canvas, paint, cells, widths, width - 2 * margin, margin, y, rowHeight);
        paint.setColor(Color.LTGRAY);
        canvas.drawLine(margin, y + rowHeight, width - margin, y + rowHeight, paint);
        return y + rowHeight;
    }

    private static void drawLandscapeCells(Canvas canvas, Paint paint, String[] cells, float[] widths,
                                           int tableWidth, int margin, int y, int rowHeight) {
        float right = margin + tableWidth;
        paint.setTextAlign(Paint.Align.RIGHT);
        for (int i = 0; i < cells.length; i++) {
            float cellWidth = widths[i] * tableWidth;
            String text = truncate(paint, safe(cells[i]), cellWidth - 8);
            canvas.drawText(text, right - 4, y + rowHeight - 8, paint);
            right -= cellWidth;
        }
    }

    private static void drawLandscapeSignatures(Canvas canvas, int width, int height, int margin) {
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.BLACK);
        paint.setTextSize(10);
        paint.setFakeBoldText(true);
        paint.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText("مدير المحروقات", width - margin, height - 44, paint);
        paint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText("رئيس قسم المراجعة", width / 2f, height - 44, paint);
        paint.setTextAlign(Paint.Align.LEFT);
        canvas.drawText("القائد", margin, height - 44, paint);
        paint.setFakeBoldText(false);
        canvas.drawText("التوقيع: ______________", margin, height - 23, paint);
        paint.setTextAlign(Paint.Align.CENTER);
        canvas.drawText("التوقيع: ______________", width / 2f, height - 23, paint);
        paint.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText("التوقيع: ______________", width - margin, height - 23, paint);
    }

    private static String safe(String value) {
        return value == null ? "" : value;
    }

    private static String join(String a, String b) {
        if (a == null) a = "";
        if (b == null) b = "";
        if (a.isEmpty()) return b;
        if (b.isEmpty()) return a;
        return a + " - " + b;
    }

    private static String fmt(double v) {
        if (v == Math.floor(v)) return String.valueOf((long) v);
        return String.format(Locale.US, "%.1f", v);
    }
}
