package com.najda.fueldistribution;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.najda.fueldistribution.utils.BackupUtils;
import com.najda.fueldistribution.utils.DateUtils;

import java.io.File;
import java.io.IOException;

public class BackupActivity extends AppCompatActivity {

    private TextView tvStatus;
    private File pendingBackupFile;

    private final ActivityResultLauncher<String> createDocumentLauncher =
            registerForActivityResult(new ActivityResultContracts.CreateDocument("application/octet-stream"), uri -> {
                if (uri == null || pendingBackupFile == null) return;
                try {
                    BackupUtils.exportToUri(this, pendingBackupFile, uri);
                    tvStatus.setText(getString(R.string.backup_success));
                    Toast.makeText(this, R.string.backup_success, Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    tvStatus.setText("خطأ: " + e.getMessage());
                }
            });

    private final ActivityResultLauncher<String[]> openDocumentLauncher =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
                if (uri == null) return;
                confirmRestore(uri);
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_backup);

        tvStatus = findViewById(R.id.tvStatus);
        Button btnBackupNow = findViewById(R.id.btnBackupNow);
        Button btnRestoreNow = findViewById(R.id.btnRestoreNow);

        btnBackupNow.setOnClickListener(v -> doBackup());
        btnRestoreNow.setOnClickListener(v -> openDocumentLauncher.launch(new String[]{"*/*"}));
    }

    private void doBackup() {
        try {
            pendingBackupFile = BackupUtils.backupToLocalFile(this);
            tvStatus.setText(getString(R.string.backup_success) + "\n" + pendingBackupFile.getAbsolutePath());
            // Also offer to let the user save a copy anywhere they choose (SD card, shared folder, etc.)
            createDocumentLauncher.launch("fuel_backup_" + DateUtils.today() + ".db");
        } catch (IOException e) {
            tvStatus.setText("خطأ: " + e.getMessage());
        }
    }

    private void confirmRestore(Uri sourceUri) {
        new AlertDialog.Builder(this)
                .setMessage(R.string.restore_confirm)
                .setPositiveButton(R.string.restore_now, (dialog, which) -> doRestore(sourceUri))
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void doRestore(Uri sourceUri) {
        try {
            // Close the shared DatabaseHelper connection before overwriting the file on disk.
            DatabaseHelper.getInstance(this).close();
            BackupUtils.restoreFromUri(this, sourceUri);
            Toast.makeText(this, R.string.restore_success, Toast.LENGTH_LONG).show();

            // Restart the app cleanly so all screens read the restored data.
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        } catch (IOException e) {
            tvStatus.setText("خطأ أثناء الاستعادة: " + e.getMessage());
        }
    }
}
