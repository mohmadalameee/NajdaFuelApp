package com.najda.fueldistribution;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.najda.fueldistribution.models.Recipient;

public class AddEditRecipientActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private EditText etName, etRank, etUnit, etQuota, etFuelType, etPhone, etNotes;
    private long recipientId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_recipient);

        db = DatabaseHelper.getInstance(this);

        etName = findViewById(R.id.etName);
        etRank = findViewById(R.id.etRank);
        etUnit = findViewById(R.id.etUnit);
        etQuota = findViewById(R.id.etQuota);
        etFuelType = findViewById(R.id.etFuelType);
        etPhone = findViewById(R.id.etPhone);
        etNotes = findViewById(R.id.etNotes);

        android.widget.Button btnSave = findViewById(R.id.btnSave);
        android.widget.Button btnDelete = findViewById(R.id.btnDelete);

        recipientId = getIntent().getLongExtra(RecipientsActivity.EXTRA_RECIPIENT_ID, -1);
        if (recipientId > 0) {
            setTitle(R.string.edit);
            btnDelete.setVisibility(android.view.View.VISIBLE);
            Recipient r = db.getRecipientById(recipientId);
            if (r != null) {
                etName.setText(r.getName());
                etRank.setText(r.getRank());
                etUnit.setText(r.getUnit());
                etQuota.setText(formatNumber(r.getMonthlyQuota()));
                etFuelType.setText(r.getFuelType());
                etPhone.setText(r.getPhone());
                etNotes.setText(r.getNotes());
            }
        }

        btnSave.setOnClickListener(v -> save());
        btnDelete.setOnClickListener(v -> confirmDelete());
    }

    private void save() {
        String name = text(etName);
        if (name.isEmpty()) {
            etName.setError(getString(R.string.field_required));
            return;
        }
        double quota = 0;
        try {
            String q = text(etQuota);
            if (!q.isEmpty()) quota = Double.parseDouble(q);
        } catch (NumberFormatException e) {
            etQuota.setError(getString(R.string.field_required));
            return;
        }

        Recipient r = new Recipient();
        r.setId(recipientId);
        r.setName(name);
        r.setRank(text(etRank));
        r.setUnit(text(etUnit));
        r.setMonthlyQuota(quota);
        r.setFuelType(text(etFuelType));
        r.setPhone(text(etPhone));
        r.setNotes(text(etNotes));

        if (recipientId > 0) {
            db.updateRecipient(r);
        } else {
            db.insertRecipient(r);
        }
        Toast.makeText(this, R.string.saved_success, Toast.LENGTH_SHORT).show();
        finish();
    }

    private void confirmDelete() {
        new AlertDialog.Builder(this)
                .setMessage(R.string.delete_confirm)
                .setPositiveButton(R.string.delete, (dialog, which) -> {
                    db.deleteRecipient(recipientId);
                    finish();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private String text(EditText e) {
        return e.getText() == null ? "" : e.getText().toString().trim();
    }

    private String formatNumber(double d) {
        if (d == Math.floor(d)) return String.valueOf((long) d);
        return String.valueOf(d);
    }
}
