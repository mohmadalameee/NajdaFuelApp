package com.najda.fueldistribution.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.najda.fueldistribution.R;
import com.najda.fueldistribution.models.CommanderDirective;

import java.util.ArrayList;
import java.util.List;

public class CommanderDirectiveAdapter extends RecyclerView.Adapter<CommanderDirectiveAdapter.ViewHolder> {

    public interface OnItemActionListener {
        void onClick(CommanderDirective directive);
        void onLongClick(CommanderDirective directive);
    }

    private List<CommanderDirective> items = new ArrayList<>();
    private final OnItemActionListener listener;

    public CommanderDirectiveAdapter(OnItemActionListener listener) {
        this.listener = listener;
    }

    public void setItems(List<CommanderDirective> items) {
        this.items = items;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_commander_directive, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        CommanderDirective d = items.get(position);
        holder.tvBeneficiary.setText(d.getBeneficiaryName());
        holder.tvQuantity.setText(formatNumber(d.getQuantity()) + " لتر");

        String directiveNo = d.getDirectiveNumber() == null || d.getDirectiveNumber().isEmpty()
                ? "" : " — رقم التوجيه: " + d.getDirectiveNumber();
        holder.tvDateDirective.setText(d.getDate() + directiveNo);

        holder.tvReason.setText(d.getReason() == null ? "" : d.getReason());
        holder.tvReason.setVisibility(d.getReason() == null || d.getReason().isEmpty() ? View.GONE : View.VISIBLE);

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onClick(d);
        });
        holder.itemView.setOnLongClickListener(v -> {
            if (listener != null) {
                listener.onLongClick(d);
                return true;
            }
            return false;
        });
    }

    private String formatNumber(double v) {
        if (v == Math.floor(v)) return String.valueOf((long) v);
        return String.valueOf(v);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvBeneficiary, tvQuantity, tvDateDirective, tvReason;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvBeneficiary = itemView.findViewById(R.id.tvBeneficiary);
            tvQuantity = itemView.findViewById(R.id.tvQuantity);
            tvDateDirective = itemView.findViewById(R.id.tvDateDirective);
            tvReason = itemView.findViewById(R.id.tvReason);
        }
    }
}
