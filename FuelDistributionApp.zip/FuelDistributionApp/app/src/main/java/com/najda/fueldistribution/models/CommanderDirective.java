package com.najda.fueldistribution.models;

public class CommanderDirective {
    private long id;
    private String directiveNumber;
    private String date;
    private String beneficiaryName;
    private double quantity;
    private String reason;
    private String notes;

    public CommanderDirective() {}

    public CommanderDirective(long id, String directiveNumber, String date, String beneficiaryName,
                               double quantity, String reason, String notes) {
        this.id = id;
        this.directiveNumber = directiveNumber;
        this.date = date;
        this.beneficiaryName = beneficiaryName;
        this.quantity = quantity;
        this.reason = reason;
        this.notes = notes;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getDirectiveNumber() { return directiveNumber; }
    public void setDirectiveNumber(String directiveNumber) { this.directiveNumber = directiveNumber; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getBeneficiaryName() { return beneficiaryName; }
    public void setBeneficiaryName(String beneficiaryName) { this.beneficiaryName = beneficiaryName; }

    public double getQuantity() { return quantity; }
    public void setQuantity(double quantity) { this.quantity = quantity; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
