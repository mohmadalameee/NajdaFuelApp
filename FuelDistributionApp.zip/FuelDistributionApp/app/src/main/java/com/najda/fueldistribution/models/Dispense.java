package com.najda.fueldistribution.models;

public class Dispense {

    public static final int TYPE_REGULAR = 1;
    public static final int TYPE_COMMANDER = 2;
    public static final int TYPE_EMERGENCY = 3;

    private long id;
    private long recipientId;
    private String recipientName; // populated on join queries, not stored on this table
    private String date; // yyyy-MM-dd
    private double quantity;
    private int dispenseType;
    private String directiveNumber;
    private String notes;

    public Dispense() {}

    public Dispense(long id, long recipientId, String date, double quantity,
                     int dispenseType, String directiveNumber, String notes) {
        this.id = id;
        this.recipientId = recipientId;
        this.date = date;
        this.quantity = quantity;
        this.dispenseType = dispenseType;
        this.directiveNumber = directiveNumber;
        this.notes = notes;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public long getRecipientId() { return recipientId; }
    public void setRecipientId(long recipientId) { this.recipientId = recipientId; }

    public String getRecipientName() { return recipientName; }
    public void setRecipientName(String recipientName) { this.recipientName = recipientName; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public double getQuantity() { return quantity; }
    public void setQuantity(double quantity) { this.quantity = quantity; }

    public int getDispenseType() { return dispenseType; }
    public void setDispenseType(int dispenseType) { this.dispenseType = dispenseType; }

    public String getDirectiveNumber() { return directiveNumber; }
    public void setDirectiveNumber(String directiveNumber) { this.directiveNumber = directiveNumber; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public static String typeLabel(int type) {
        switch (type) {
            case TYPE_COMMANDER: return "صرف بتوجيه القائد العام";
            case TYPE_EMERGENCY: return "صرف طارئ";
            default: return "صرف من المقرر الشهري";
        }
    }
}
