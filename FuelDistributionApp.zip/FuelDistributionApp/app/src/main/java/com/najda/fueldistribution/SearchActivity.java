package com.najda.fueldistribution;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.najda.fueldistribution.adapters.CommanderDirectiveAdapter;
import com.najda.fueldistribution.adapters.DispenseAdapter;
import com.najda.fueldistribution.adapters.RecipientsAdapter;
import com.najda.fueldistribution.models.CommanderDirective;
import com.najda.fueldistribution.models.Dispense;
import com.najda.fueldistribution.models.Recipient;

import java.util.Collections;
import java.util.List;

public class SearchActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private EditText etSearch;
    private TextView tvEmpty, tvRecipientsHeader, tvDispensesHeader, tvCommanderHeader;
    private RecipientsAdapter recipientsAdapter;
    private DispenseAdapter dispenseAdapter;
    private CommanderDirectiveAdapter commanderAdapter;
    private RecyclerView recyclerRecipients, recyclerDispenses, recyclerCommander;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        db = DatabaseHelper.getInstance(this);
        etSearch = findViewById(R.id.etSearch);
        tvEmpty = findViewById(R.id.tvEmpty);
        tvRecipientsHeader = findViewById(R.id.tvRecipientsHeader);
        tvDispensesHeader = findViewById(R.id.tvDispensesHeader);
        tvCommanderHeader = findViewById(R.id.tvCommanderHeader);

        recyclerRecipients = findViewById(R.id.recyclerRecipients);
        recyclerDispenses = findViewById(R.id.recyclerDispenses);
        recyclerCommander = findViewById(R.id.recyclerCommander);

        recipientsAdapter = new RecipientsAdapter(recipient -> {
            Intent i = new Intent(this, RecipientDetailActivity.class);
            i.putExtra(RecipientsActivity.EXTRA_RECIPIENT_ID, recipient.getId());
            startActivity(i);
        });
        recyclerRecipients.setLayoutManager(new LinearLayoutManager(this));
        recyclerRecipients.setAdapter(recipientsAdapter);

        dispenseAdapter = new DispenseAdapter(true, null);
        recyclerDispenses.setLayoutManager(new LinearLayoutManager(this));
        recyclerDispenses.setAdapter(dispenseAdapter);

        commanderAdapter = new CommanderDirectiveAdapter(new CommanderDirectiveAdapter.OnItemActionListener() {
            @Override
            public void onClick(CommanderDirective directive) {
                Intent i = new Intent(SearchActivity.this, AddCommanderDirectiveActivity.class);
                i.putExtra(CommanderDirectivesActivity.EXTRA_DIRECTIVE_ID, directive.getId());
                startActivity(i);
            }

            @Override
            public void onLongClick(CommanderDirective directive) {}
        });
        recyclerCommander.setLayoutManager(new LinearLayoutManager(this));
        recyclerCommander.setAdapter(commanderAdapter);

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                runSearch(s.toString().trim());
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        runSearch("");
    }

    private void runSearch(String query) {
        List<Recipient> recipients;
        List<Dispense> dispenses;
        List<CommanderDirective> directives;

        if (query.isEmpty()) {
            recipients = Collections.emptyList();
            dispenses = Collections.emptyList();
            directives = Collections.emptyList();
        } else {
            recipients = db.searchRecipients(query);
            dispenses = db.searchDispenses(query);
            directives = db.searchCommanderDirectives(query);
        }

        recipientsAdapter.setItems(recipients);
        dispenseAdapter.setItems(dispenses);
        commanderAdapter.setItems(directives);

        tvRecipientsHeader.setVisibility(recipients.isEmpty() ? View.GONE : View.VISIBLE);
        recyclerRecipients.setVisibility(recipients.isEmpty() ? View.GONE : View.VISIBLE);

        tvDispensesHeader.setVisibility(dispenses.isEmpty() ? View.GONE : View.VISIBLE);
        recyclerDispenses.setVisibility(dispenses.isEmpty() ? View.GONE : View.VISIBLE);

        tvCommanderHeader.setVisibility(directives.isEmpty() ? View.GONE : View.VISIBLE);
        recyclerCommander.setVisibility(directives.isEmpty() ? View.GONE : View.VISIBLE);

        boolean allEmpty = recipients.isEmpty() && dispenses.isEmpty() && directives.isEmpty();
        tvEmpty.setVisibility(allEmpty && !query.isEmpty() ? View.VISIBLE : View.GONE);
    }
}
