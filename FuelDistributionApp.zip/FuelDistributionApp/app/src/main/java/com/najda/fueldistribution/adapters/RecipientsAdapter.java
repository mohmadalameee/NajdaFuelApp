package com.najda.fueldistribution.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.najda.fueldistribution.R;
import com.najda.fueldistribution.models.Recipient;

import java.util.ArrayList;
import java.util.List;

public class RecipientsAdapter extends RecyclerView.Adapter<RecipientsAdapter.ViewHolder> {

    public interface OnRecipientClickListener {
        void onClick(Recipient recipient);
    }

    private List<Recipient> items = new ArrayList<>();
    private final OnRecipientClickListener listener;

    public RecipientsAdapter(OnRecipientClickListener listener) {
        this.listener = listener;
    }

    public void setItems(List<Recipient> items) {
        this.items = items;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_recipient, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Recipient r = items.get(position);
        holder.tvName.setText(r.getName());
        String rankUnit = (r.getRank() == null ? "" : r.getRank()) +
                (r.getUnit() != null && !r.getUnit().isEmpty() ? " - " + r.getUnit() : "");
        holder.tvRankUnit.setText(rankUnit);
        holder.tvQuota.setText("المقرر الشهري: " + formatNumber(r.getMonthlyQuota()) + " لتر");
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onClick(r);
        });
    }

    private String formatNumber(double d) {
        if (d == Math.floor(d)) return String.valueOf((long) d);
        return String.valueOf(d);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvRankUnit, tvQuota;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvRankUnit = itemView.findViewById(R.id.tvRankUnit);
            tvQuota = itemView.findViewById(R.id.tvQuota);
        }
    }
}
