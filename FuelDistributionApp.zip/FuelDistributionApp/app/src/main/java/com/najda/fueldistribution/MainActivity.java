package com.najda.fueldistribution;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Touching the DB helper here ensures the database and tables
        // are created on first app launch, before any screen needs them.
        DatabaseHelper.getInstance(this).getReadableDatabase();

        Button btnRecipients = findViewById(R.id.btnRecipients);
        Button btnCommander = findViewById(R.id.btnCommander);
        Button btnReports = findViewById(R.id.btnReports);
        Button btnSearch = findViewById(R.id.btnSearch);
        Button btnBackup = findViewById(R.id.btnBackup);

        btnRecipients.setOnClickListener(v -> startActivity(new Intent(this, RecipientsActivity.class)));
        btnCommander.setOnClickListener(v -> startActivity(new Intent(this, CommanderDirectivesActivity.class)));
        btnReports.setOnClickListener(v -> startActivity(new Intent(this, ReportsActivity.class)));
        btnSearch.setOnClickListener(v -> startActivity(new Intent(this, SearchActivity.class)));
        btnBackup.setOnClickListener(v -> startActivity(new Intent(this, BackupActivity.class)));
    }
}
