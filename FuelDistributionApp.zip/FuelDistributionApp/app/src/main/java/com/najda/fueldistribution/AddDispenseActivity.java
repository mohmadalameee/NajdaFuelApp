package com.najda.fueldistribution;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.najda.fueldistribution.models.Dispense;
import com.najda.fueldistribution.models.Recipient;
import com.najda.fueldistribution.utils.DateUtils;

import java.util.Calendar;
import java.util.Locale;

public class AddDispenseActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private long recipientId;
    private EditText etDate, etQuantity, etDirective, etNotes;
    private RadioGroup rgType;
    private String selectedDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_dispense);

        db = DatabaseHelper.getInstance(this);
        recipientId = getIntent().getLongExtra(RecipientsActivity.EXTRA_RECIPIENT_ID, -1);

        TextView tvHeader = findViewById(R.id.tvRecipientHeader);
        Recipient r = db.getRecipientById(recipientId);
        tvHeader.setText(r != null ? r.getName() : "");

        etDate = findViewById(R.id.etDate);
        etQuantity = findViewById(R.id.etQuantity);
        etDirective = findViewById(R.id.etDirective);
        etNotes = findViewById(R.id.etNotes);
        rgType = findViewById(R.id.rgType);
        Button btnSave = findViewById(R.id.btnSave);

        selectedDate = DateUtils.today();
        etDate.setText(selectedDate);
        etDate.setOnClickListener(v -> showDatePicker());

        btnSave.setOnClickListener(v -> save());
    }

    private void showDatePicker() {
        Calendar cal = Calendar.getInstance();
        try {
            String[] parts = selectedDate.split("-");
            cal.set(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]) - 1, Integer.parseInt(parts[2]));
        } catch (Exception ignored) {}

        new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            selectedDate = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, dayOfMonth);
            etDate.setText(selectedDate);
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void save() {
        String qtyStr = etQuantity.getText() == null ? "" : etQuantity.getText().toString().trim();
        if (qtyStr.isEmpty()) {
            etQuantity.setError(getString(R.string.field_required));
            return;
        }
        double quantity;
        try {
            quantity = Double.parseDouble(qtyStr);
        } catch (NumberFormatException e) {
            etQuantity.setError(getString(R.string.field_required));
            return;
        }

        int type;
        int checkedId = rgType.getCheckedRadioButtonId();
        if (checkedId == R.id.rbCommander) {
            type = Dispense.TYPE_COMMANDER;
        } else if (checkedId == R.id.rbEmergency) {
            type = Dispense.TYPE_EMERGENCY;
        } else {
            type = Dispense.TYPE_REGULAR;
        }

        Dispense d = new Dispense();
        d.setRecipientId(recipientId);
        d.setDate(selectedDate);
        d.setQuantity(quantity);
        d.setDispenseType(type);
        d.setDirectiveNumber(etDirective.getText() == null ? "" : etDirective.getText().toString().trim());
        d.setNotes(etNotes.getText() == null ? "" : etNotes.getText().toString().trim());

        db.insertDispense(d);
        Toast.makeText(this, R.string.saved_success, Toast.LENGTH_SHORT).show();
        finish();
    }
}
