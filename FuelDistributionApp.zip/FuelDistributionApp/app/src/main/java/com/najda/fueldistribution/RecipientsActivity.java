package com.najda.fueldistribution;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.najda.fueldistribution.adapters.RecipientsAdapter;
import com.najda.fueldistribution.models.Recipient;

import java.util.List;

public class RecipientsActivity extends AppCompatActivity {

    public static final String EXTRA_RECIPIENT_ID = "recipient_id";

    private DatabaseHelper db;
    private RecipientsAdapter adapter;
    private RecyclerView recyclerView;
    private TextView tvEmpty;
    private EditText etSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipients);

        db = DatabaseHelper.getInstance(this);

        recyclerView = findViewById(R.id.recyclerView);
        tvEmpty = findViewById(R.id.tvEmpty);
        etSearch = findViewById(R.id.etSearch);
        FloatingActionButton fabAdd = findViewById(R.id.fabAdd);

        adapter = new RecipientsAdapter(recipient -> {
            Intent i = new Intent(this, RecipientDetailActivity.class);
            i.putExtra(EXTRA_RECIPIENT_ID, recipient.getId());
            startActivity(i);
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        fabAdd.setOnClickListener(v -> startActivity(new Intent(this, AddEditRecipientActivity.class)));

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                loadData(s.toString());
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData(etSearch.getText() != null ? etSearch.getText().toString() : "");
    }

    private void loadData(String query) {
        List<Recipient> list = (query == null || query.trim().isEmpty())
                ? db.getAllRecipients()
                : db.searchRecipients(query.trim());
        adapter.setItems(list);
        boolean empty = list.isEmpty();
        tvEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(empty ? View.GONE : View.VISIBLE);
    }
}
